var express = require("express"),
	app = express(),
	bodyParser = require("body-parser"),
	mongoose = require("mongoose"),
methodOverride = require("method-override");

//APP CONFIG
mongoose.connect("mongodb://localhost/concerts");
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(methodOverride("_method")); 
app.use(bodyParser.urlencoded({extended: true}));



var concertSchema = new mongoose.Schema({
    title: String,
    image: String,
    body: String,
  
});
var Concert = mongoose.model("Concert", concertSchema);


app.get("/", function(req, res){
   res.redirect("/concerts");
});


// INDEX ROUTE
app.get("/concerts", function(req, res){
  Concert.find({}, function(err,concerts){
	  if(err){
		  console.log("ERROR");
	  }else{
		  res.render("index", {concerts: concerts});
	  }
  })
		
	
});

app.get("/concerts/new", function(req,res){
	res.render("new");
	
});

app.post("/concerts", function(req, res){
	Concert.create(req.body.concert, function(err, newConcert){
		if(err){
			res.render("new");
		}else{
			res.redirect("/concerts");
		}
		
	})
	
});


//SHOW

app.get("/concerts/:id", function(req, res){
   Concert.findById(req.params.id, function(err, foundConcert){
       if(err){
           res.redirect("/concerts");
       } else {
           res.render("show", {concert: foundConcert});
       }
   })
});

//EDITTT

app.get("/concerts/:id/edit", function(req,res){
	Concert.findById(req.params.id, function(err, foundConcert){
		if(err){
			res.redirect("/concerts");
		}else{
			res.render("edit", {concert: foundConcert});
		}
		
	})

	
});

app.put("/concerts/:id", function(req, res){
	 
  Concert.findByIdAndUpdate(req.params.id, req.body.concert, function(err, updatedConcert){
      if(err){
          res.redirect("/concerts");
      }  else {
          res.redirect("/concerts/" + req.params.id);
      }
   });
});


app.delete("/concerts/:id", function(req, res){
   //destroy blog
   Concert.findByIdAndRemove(req.params.id, function(err){
       if(err){
           res.redirect("/concerts");
       } else {
           res.redirect("/concerts");
       }
   })
   //redirect somewhere
});



var port = process.env.PORT || 3000;
app.listen(port, function () {
  console.log("Server started!");
});
	
